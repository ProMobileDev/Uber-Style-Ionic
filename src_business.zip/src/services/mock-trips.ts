export let TRIPS = [
  {
    id: 1,
    from: 'Royal City',
    to: 'Vietnam - France hospital',
    time: '2016-01-02'
  },
  {
    id: 2,
    from: 'BigC',
    to: 'Phao Dai Lang',
    time: '2015-12-11'
  },
  {
    id: 3,
    from: 'Royal City',
    to: '784 Lang',
    time: '2015-11-10'
  },
  {
    id: 4,
    from: 'Royal City',
    to: 'Vietnam - France hospital',
    time: '2015-11-10'
  }
];