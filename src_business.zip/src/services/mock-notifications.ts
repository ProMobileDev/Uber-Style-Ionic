export let NOTIFICATIONS = [
  {
    id: 1,
    title: "New price from Jan 2016",
    content: "",
    createdAt: "2016-02-14 12:00:00",
    read: true
  },
  {
    id: 2,
    title: "New version 1.1.1",
    content: "",
    createdAt: "2016-02-13 12:00:00",
    read: false
  },
  {
    id: 3,
    title: "New version 1.1.0",
    content: "",
    createdAt: "2016-02-12 12:00:00",
    read: false
  }
]