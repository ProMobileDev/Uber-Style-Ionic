export let DRIVERS = [
  {
    id: 1,
    name: "Edward Thomas",
    plate: "29A578.89",
    brand: "Kia Morning",
    distance: 0.6,
    status: "Bidding"
  },
  {
    id: 2,
    name: "Denis Suarez",
    plate: "29A578.89",
    brand: "Kia Morning",
    distance: 0.6,
    status: "Contacting"
  },
  {
    id: 3,
    name: "Karim Benzema",
    plate: "29A578.89",
    brand: "Kia Morning",
    distance: 0.6,
    status: "Contacting"
  },
  {
    id: 4,
    name: "Martin Montoya",
    plate: "29A578.89",
    brand: "Kia Morning",
    distance: 0.6,
    status: "Contacting"
  },
];