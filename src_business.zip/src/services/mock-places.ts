export let PLACES = [
  {
    name: "Bach Mai hospital",
    address: "Giai Phong street, Hanoi, Vietnam",
    distance: 1
  },
  {
    name: "Vietnam - France hospital",
    address: "Phuong Mai street, Hanoi, Vietnam",
    distance: 1.2
  },
  {
    name: "Pico plaza",
    address: "No 02 Truong Chinh street, Hanoi, Vietnam",
    distance: 1.3
  },
  {
    name: "Pho Vong",
    address: "Pho Vong street, Hanoi, Vietnam",
    distance: 1.4
  },
  {
    name: "iMobile",
    address: "Pho Vong street, Hanoi, Vietnam",
    distance: 1.5
  }
];